<?php $__env->startSection('page_active', 'active'); ?>
<?php $__env->startSection('title', 'Hotels'); ?>
<?php $__env->startSection('admin_content'); ?>

    <div class="container-fluid" id="container-wrapper">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Hotels</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="./">Home</a></li>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active" aria-current="page">DataTables</li>
            </ol>
        </div>

        <!-- Row -->
        <div class="row">


            <!-- DataTable with Hover -->
            <div class="col-lg-12">
                <div class="col-lg-6">
                    <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="card mb-4">

                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-primary">Hotel</h6>
                        <a class="btn btn-success" href="<?php echo e(route('hotel.create')); ?>">Add Hotel</a>
                    </div>
                    <div class="table-responsive p-3">
                        <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                            <thead class="thead-light">
                                <tr>
                                    <th>Sno</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Description </th>
                                    <th>Price</th>
                                    <th>Discount Price</th>
                                    <th>Deal</th>
                                    <th>Created At</th>
                                    <th>Status</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Sno</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Description </th>
                                    <th>Price</th>
                                    <th>Discount Price</th>
                                    <th>Deal</th>
                                    <th>Created At</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>

                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><img src="<?php echo e(url('uploads/hotel/' . $item->image)); ?>" width="100px"
                                                height="100px" alt=""></td>
                                        <td><?php echo e($item->title); ?></td>
                                        <td><?php echo e($item->description); ?></td>
                                        <td><?php echo e($item->price); ?></td>
                                        <td><?php echo e($item->discount_price); ?></td>
                                        <td><?php echo e($item->deal); ?></td>

                                        <td><?php echo e($item->created_at->diffforhumans()); ?></td>
                                        <td>
                                            <?php if($item->status == 1): ?>
                                                <span class="badge badge-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="white-space: nowrap;">
                                            <a class="btn btn-primary" title="view details"
                                                href="<?php echo e(route('hotel.edit', $item->id)); ?>"><i class="fas fa-eye"></i>
                                            </a>
                                            <?php if($item->status == 1): ?>
                                                <a class="btn btn-success" title="Deactive"
                                                    href="<?php echo e(url('admin/hotel/status/0', $item->id)); ?> "><i
                                                        class="fas fa-toggle-on"></i></a>
                                            <?php else: ?>
                                                <a class="btn btn-danger" title="Active"
                                                    href="<?php echo e(url('admin/hotel/status/1', $item->id)); ?> "><i
                                                        class="fas fa-toggle-off"></i></a>
                                            <?php endif; ?>
                                            

                                            <form action="<?php echo e(route('hotel.destroy', $item->id)); ?>" method="post"
                                                style="display:inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button class="btn btn-danger" title="Delete" type="sumit"><i
                                                        class="fa fa-trash" aria-hidden="true"></i> </button>
                                            </form>

                                        </td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--Row-->

        <!-- Documentation Link -->




    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kapil\Desktop\Reactjs\hotelbackend\resources\views/admin/hotel/index.blade.php ENDPATH**/ ?>